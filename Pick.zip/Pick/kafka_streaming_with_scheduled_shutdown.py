"""
Kafka Filter Streaming Pipeline with Scheduled Shutdown & Email Reports
========================================================================

Production PySpark Structured Streaming with daily shutdown and email notifications.

New Features in v2.0
--------------------
* 🕐 Scheduled midnight shutdown (configurable time)
* 📧 Automated daily email reports with statistics
* ♻️  Automatic restart after 30-minute cooldown
* 📊 Daily statistics tracking (separate from lifetime)
* 🎨 Beautiful HTML email templates
* ⚙️  Fully configurable via environment variables

This script will:
1. Run continuously processing Kafka messages
2. Track daily statistics separately from lifetime stats  
3. At midnight (00:00), automatically:
   - Collect daily statistics summary
   - Send formatted email report
   - Log summary to console
   - Reset daily counters
   - Gracefully shutdown queries
   - Wait 30 minutes
   - Restart automatically

Environment Variables - Email
------------------------------
SMTP_HOST               : SMTP server (default: smtp.gmail.com)
SMTP_PORT               : SMTP port (default: 587)
SMTP_USERNAME           : SMTP auth username
SMTP_PASSWORD           : SMTP auth password
EMAIL_FROM              : Sender email address
EMAIL_TO                : Recipients (comma-separated)
EMAIL_SUBJECT_PREFIX    : Subject prefix (default: [Kafka Streaming])

Environment Variables - Scheduling
-----------------------------------
SHUTDOWN_HOUR           : Hour to shutdown (default: 0 = midnight)
SHUTDOWN_MINUTE         : Minute to shutdown (default: 0)
RESTART_DELAY_MINUTES   : Minutes before restart (default: 30)
ENABLE_AUTO_RESTART     : Enable auto-restart (default: true)

Usage Example
-------------
export SMTP_HOST="smtp.company.com"
export SMTP_USERNAME="kafka-alerts@company.com"
export SMTP_PASSWORD="secret"
export EMAIL_FROM="kafka-alerts@company.com"
export EMAIL_TO="team@company.com,manager@company.com"
export SHUTDOWN_HOUR="0"
export SHUTDOWN_MINUTE="0"
export ENABLE_AUTO_RESTART="true"

spark-submit kafka_streaming_with_scheduled_shutdown.py

:Author: IDP Liabilities Team  
:Version: 2.0.0
:Date: February 2026
"""

import os
import sys
import signal
import logging
import time
import atexit
import threading
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import col, from_json, when, lit
from pyspark.sql.types import *
from pyspark.sql.streaming import StreamingQuery

__version__ = "2.0.0"
__author__ = "IDP Liabilities Team"
__status__ = "Production"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("KafkaScheduledStreaming")


# ---------------------------------------------------------------------------
# CONFIGURATION
# ---------------------------------------------------------------------------

class Config:
    """Central configuration - all settings from environment variables."""
    
    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS")
    INPUT_TOPIC: str = os.getenv("INPUT_TOPIC")
    INPUT_TOPIC_GROUP_ID: str = os.getenv("INPUT_TOPIC_GROUP_ID")
    OUTPUT_TOPIC: str = os.getenv("OUTPUT_TOPIC")
    DLQ_TOPIC: str = os.getenv("DLQ_TOPIC")
    
    # Consumer
    STARTING_OFFSETS: str = os.getenv("STARTING_OFFSETS", "latest")
    MAX_OFFSETS_PER_TRIGGER: str = os.getenv("MAX_OFFSETS_PER_TRIGGER", "10000")
    TRIGGER_INTERVAL_SECS: str = os.getenv("TRIGGER_INTERVAL_SECS", "10")
    
    # Checkpointing
    CHECKPOINT_LOCATION: str = os.getenv("CHECKPOINT_LOCATION")
    DLQ_CHECKPOINT_LOCATION: str = os.getenv("DLQ_CHECKPOINT_LOCATION")
    CLEAN_CHECKPOINT_ON_START: str = os.getenv("CLEAN_CHECKPOINT_ON_START", "false")
    
    # Application
    APP_NAME: str = os.getenv("APP_NAME", "KafkaScheduledStreaming")
    KAFKA_PRODUCER_IDEMPOTENT: str = "true"
    
    # Security
    INGESTION_CREDENTIALS: str = os.getenv("ingestion_credentials", "")
    KAFKA_SECURITY_PROTOCOL: str = "SASL_SSL"
    KAFKA_SASL_MECHANISM: str = "SCRAM-SHA-512"
    KAFKA_SASL_USERNAME: str = os.getenv("KAFKA_SASL_USERNAME", "")
    KAFKA_SASL_PASSWORD: str = os.getenv("KAFKA_SASL_PASSWORD", "")
    
    # Email
    SMTP_HOST: str = os.getenv("SMTP_HOST", "smtp.gmail.com")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USERNAME: str = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")
    EMAIL_FROM: str = os.getenv("EMAIL_FROM", "")
    EMAIL_TO: str = os.getenv("EMAIL_TO", "")
    EMAIL_SUBJECT_PREFIX: str = os.getenv("EMAIL_SUBJECT_PREFIX", "[Kafka Streaming]")
    
    # Scheduling
    SHUTDOWN_HOUR: int = int(os.getenv("SHUTDOWN_HOUR", "0"))
    SHUTDOWN_MINUTE: int = int(os.getenv("SHUTDOWN_MINUTE", "0"))
    RESTART_DELAY_MINUTES: int = int(os.getenv("RESTART_DELAY_MINUTES", "30"))
    ENABLE_AUTO_RESTART: bool = os.getenv("ENABLE_AUTO_RESTART", "true").lower() == "true"


# ---------------------------------------------------------------------------
# SCHEMA
# ---------------------------------------------------------------------------

INPUT_SCHEMA = (
    StructType()
    .add("table", StringType(), True)
    .add("op_type", StringType(), True)
    .add("op_ts", StringType(), True)
    .add("current_ts", StringType(), True)
    .add("pos", StringType(), True)
    .add("PRIMEKEY", StringType(), True)
    .add("ADJAMOUNT", StringType(), True)
    .add("ADJCODE", StringType(), True)
    .add("ADJDATE", StringType(), True)
    .add("ADJFLAG", StringType(), True)
    .add("ADJREF", StringType(), True)
    .add("ADJREMARKS", StringType(), True)
    .add("ADJTYPE", StringType(), True)
    .add("ADJUID", StringType(), True)
    .add("AMOUNT", StringType(), True)
    .add("AMOUNTRULE", StringType(), True)
    .add("AMOUNTSPLIT", StringType(), True)
    .add("APINAME", StringType(), True)
    .add("BRANCH", StringType(), True)
    .add("CURRENCY", StringType(), True)
    .add("CUSTREF", StringType(), True)
    .add("ENTITY_APPLICATION", StringType(), True)
    .add("ENTITY_ID", StringType(), True)
    .add("ENTITY_TYPE", StringType(), True)
    .add("ENTRYDATE", StringType(), True)
    .add("ENTRYTIME", StringType(), True)
    .add("ERRCODE", StringType(), True)
    .add("MESSAGETYPE", StringType(), True)
    .add("MSGID", StringType(), True)
    .add("MSGTS", StringType(), True)
    .add("MSGTSDATE", StringType(), True)
    .add("ORIGMESSAGETEXT", StringType(), True)
    .add("ORIGMESSAGETYPE", StringType(), True)
    .add("ORIGMSGSOURCE", StringType(), True)
    .add("PAYEE_ACNUM", StringType(), True)
    .add("PAYEE_ACTYPE", StringType(), True)
    .add("PAYEE_ADDR", StringType(), True)
    .add("PAYEE_ADDRTYPE", StringType(), True)
    .add("PAYEE_AMOUNT", StringType(), True)
    .add("PAYEE_CODE", StringType(), True)
    .add("PAYEE_CURRENCY", StringType(), True)
    .add("PAYEE_IFSC", StringType(), True)
    .add("PAYEE_NAME", StringType(), True)
    .add("PAYEE_ORDERSEQUENCE", StringType(), True)
    .add("PAYEE_SEQNUM", StringType(), True)
    .add("PAYEE_TYPE", StringType(), True)
    .add("PAYEE_VERIFIEDADDRESS", StringType(), True)
    .add("PAYEE_VERIFIEDNAME", StringType(), True)
    .add("PAYER_ACNUM", StringType(), True)
    .add("PAYER_ACTYPE", StringType(), True)
    .add("PAYER_ADDR", StringType(), True)
    .add("PAYER_ADDRTYPE", StringType(), True)
    .add("PAYER_AMOUNT", StringType(), True)
    .add("PAYER_CODE", StringType(), True)
    .add("PAYER_CURRENCY", StringType(), True)
    .add("PAYER_DEV_APP", StringType(), True)
    .add("PAYER_DEV_CAPABILITY", StringType(), True)
    .add("PAYER_DEV_GEOCODE", StringType(), True)
    .add("PAYER_DEV_ID", StringType(), True)
    .add("PAYER_DEV_IP", StringType(), True)
    .add("PAYER_DEV_LOCATION", StringType(), True)
    .add("PAYER_DEV_OS", StringType(), True)
    .add("PAYER_DEV_TYPE", StringType(), True)
    .add("PAYER_IFSC", StringType(), True)
    .add("PAYER_MOBNUM", StringType(), True)
    .add("PAYER_NAME", StringType(), True)
    .add("PAYER_ORDERSEQUENCE", StringType(), True)
    .add("PAYER_SEQNUM", StringType(), True)
    .add("PAYER_TYPE", StringType(), True)
    .add("PAYER_VERIFIEDADDRESS", StringType(), True)
    .add("PAYER_VERIFIEDNAME", StringType(), True)
    .add("PAYMENTTYPE", StringType(), True)
    .add("PRODTYPE", StringType(), True)
    .add("PURPOSE", StringType(), True)
    .add("REFID", StringType(), True)
    .add("REFURL", StringType(), True)
    .add("RESPCODE", StringType(), True)
    .add("RESULT", StringType(), True)
    .add("STATUS", StringType(), True)
    .add("SUBTYPE", StringType(), True)
    .add("SYSREF", StringType(), True)
    .add("TIMESTAMP", StringType(), True)
    .add("TS", StringType(), True)
    .add("TXNID", StringType(), True)
    .add("TXNTS", StringType(), True)
    .add("TYPE", StringType(), True)
    .add("UPISESSION", StringType(), True)
    .add("UPISESSIONDATE", StringType(), True)
    .add("URNTXNID", StringType(), True)
    .add("VALUEDATE", StringType(), True)
    .add("VERSION", StringType(), True)
    .add("CBS_IDENTIFIER", StringType(), True)
)


# ---------------------------------------------------------------------------
# STATS COLLECTOR WITH DAILY TRACKING
# ---------------------------------------------------------------------------

class BatchStatsCollector:
    """Thread-safe stats with daily + lifetime tracking."""
    
    def __init__(self):
        self._lock = threading.Lock()
        # Lifetime
        self.total_read = 0
        self.total_valid = 0
        self.total_invalid = 0
        self.total_filtered = 0
        self.total_dropped = 0
        self.total_written = 0
        self.total_dlq_written = 0
        self.total_batches = 0
        self.app_start_time = time.time()
        # Daily
        self.daily_read = 0
        self.daily_valid = 0
        self.daily_invalid = 0
        self.daily_filtered = 0
        self.daily_written = 0
        self.daily_batches = 0
        self.daily_start_time = time.time()

    def add(self, read, valid, invalid, filtered, dropped, written, dlq_written, latency_ms):
        with self._lock:
            self.total_read += read
            self.total_valid += valid
            self.total_invalid += invalid
            self.total_filtered += filtered
            self.total_dropped += dropped
            self.total_written += written
            self.total_dlq_written += dlq_written
            self.total_batches += 1
            
            self.daily_read += read
            self.daily_valid += valid
            self.daily_invalid += invalid
            self.daily_filtered += filtered
            self.daily_written += written
            self.daily_batches += 1

        drop_pct = (dropped / valid * 100) if valid > 0 else 0.0
        dlq_pct = (invalid / read * 100) if read > 0 else 0.0
        hit_pct = (filtered / read * 100) if read > 0 else 0.0
        uptime_sec = time.time() - self.app_start_time

        logger.info(
            "\n"
            "╔══════════════════════════════════════════════════════╗\n"
            "║          BATCH #%-5d  STATS SUMMARY                  ║\n"
            "╠══════════════════════════════════════════════════════╣\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s   (%5.1f%% of valid)║\n"
            "║  %-28s %10s   (%5.1f%% of read) ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "╠══════════════════════════════════════════════════════╣\n"
            "║  %-28s %8s ms                  ║\n"
            "╠══════════════════════════════════════════════════════╣\n"
            "║  LIFETIME TOTALS                                     ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "║  %-28s %10s                    ║\n"
            "╚══════════════════════════════════════════════════════╝",
            self.total_batches,
            "Records Read", read,
            "Records Valid", valid,
            "Records Invalid(Rejected)", invalid,
            "Records Filtered", filtered, drop_pct,
            "Records Dropped", dropped, hit_pct,
            "Records Written", written,
            "Records Rejected", dlq_written,
            "Batch Latency", round(latency_ms, 2),
            "Total Read", self.total_read,
            "Total Valid", self.total_valid,
            "Total Invalid", self.total_invalid,
            "Total Filtered", self.total_filtered,
            "Total Dropped", self.total_dropped,
            "Total Written", self.total_written,
            "Total Rejected", self.total_dlq_written,
            "Uptime (sec)", round(uptime_sec, 1),
        )

    def get_daily_summary(self) -> Dict:
        with self._lock:
            runtime_hours = (time.time() - self.daily_start_time) / 3600
            return {
                "date": datetime.now().strftime("%Y-%m-%d"),
                "runtime_hours": round(runtime_hours, 2),
                "total_read": self.daily_read,
                "total_valid": self.daily_valid,
                "total_invalid": self.daily_invalid,
                "total_filtered": self.daily_filtered,
                "total_written": self.daily_written,
                "total_batches": self.daily_batches,
                "avg_throughput_per_hour": int(self.daily_read / runtime_hours) if runtime_hours > 0 else 0,
                "success_rate": round((self.daily_valid / self.daily_read * 100), 2) if self.daily_read > 0 else 0,
                "filter_efficiency": round((self.daily_filtered / self.daily_valid * 100), 2) if self.daily_valid > 0 else 0,
            }

    def reset_daily_stats(self):
        with self._lock:
            self.daily_read = 0
            self.daily_valid = 0
            self.daily_invalid = 0
            self.daily_filtered = 0
            self.daily_written = 0
            self.daily_batches = 0
            self.daily_start_time = time.time()
            logger.info("✓ Daily statistics reset")


stats = BatchStatsCollector()


# ---------------------------------------------------------------------------
# EMAIL REPORTING
# ---------------------------------------------------------------------------

def send_email_report(summary: Dict) -> bool:
    """Send beautiful HTML email with daily statistics."""
    try:
        if not Config.EMAIL_FROM or not Config.EMAIL_TO:
            logger.warning("Email configuration missing - skipping")
            return False

        subject = f"{Config.EMAIL_SUBJECT_PREFIX} Daily Report - {summary['date']}"
        
        body = f"""<!DOCTYPE html>
<html>
<head>
<style>
body{{font-family:Arial,sans-serif;margin:20px;background:#f5f5f5}}
.container{{max-width:800px;margin:0 auto;background:#fff;padding:20px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1)}}
.header{{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:30px;border-radius:8px;text-align:center}}
.header h1{{margin:0;font-size:28px}}
.header p{{margin:10px 0 0;font-size:16px;opacity:0.9}}
.stats-table{{width:100%;border-collapse:collapse;margin-top:15px}}
.stats-table th{{background:#667eea;color:#fff;padding:14px;text-align:left;font-size:14px}}
.stats-table td{{padding:12px;border-bottom:1px solid #e0e0e0;font-size:14px}}
.stats-table tr:hover{{background:#f8f9fa}}
.metric-value{{font-weight:bold;color:#667eea;font-size:16px}}
.metric-good{{color:#28a745}}
.section-title{{color:#333;font-size:20px;margin-top:30px;padding-bottom:10px;border-bottom:2px solid #667eea}}
.footer{{margin-top:40px;padding-top:20px;border-top:2px solid #e0e0e0;font-size:12px;color:#777;text-align:center}}
.highlight-box{{background:#f0f4ff;border-left:4px solid #667eea;padding:15px;margin:15px 0;border-radius:4px}}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>📊 Kafka Streaming Pipeline</h1>
<p>Daily Processing Report</p>
<p style="font-size:24px;margin-top:15px">{summary['date']}</p>
</div>
<div class="highlight-box">
<p style="margin:0;color:#555"><strong>Status:</strong> Completed ✓</p>
<p style="margin:5px 0 0;color:#555"><strong>Runtime:</strong> {summary['runtime_hours']} hours</p>
</div>
<div style="margin-top:30px">
<h2 class="section-title">📈 Processing Summary</h2>
<table class="stats-table">
<tr><th>Metric</th><th style="text-align:right">Value</th></tr>
<tr><td>Total Records Read</td><td class="metric-value" style="text-align:right">{summary['total_read']:,}</td></tr>
<tr><td>Valid Records</td><td class="metric-value metric-good" style="text-align:right">{summary['total_valid']:,}</td></tr>
<tr><td>Invalid Records (Rejected)</td><td class="metric-value" style="text-align:right;color:#ffc107">{summary['total_invalid']:,}</td></tr>
<tr><td>Filtered Records (ACQUIRER)</td><td class="metric-value" style="text-align:right">{summary['total_filtered']:,}</td></tr>
<tr><td>Records Written to Output</td><td class="metric-value metric-good" style="text-align:right">{summary['total_written']:,}</td></tr>
<tr><td>Total Batches Processed</td><td class="metric-value" style="text-align:right">{summary['total_batches']:,}</td></tr>
</table>
</div>
<div style="margin-top:30px">
<h2 class="section-title">⚡ Performance Metrics</h2>
<table class="stats-table">
<tr><th>Metric</th><th style="text-align:right">Value</th></tr>
<tr><td>Average Throughput</td><td class="metric-value" style="text-align:right">{summary['avg_throughput_per_hour']:,} records/hour</td></tr>
<tr><td>Success Rate</td><td class="metric-value metric-good" style="text-align:right">{summary['success_rate']}%</td></tr>
<tr><td>Filter Efficiency</td><td class="metric-value" style="text-align:right">{summary['filter_efficiency']}%</td></tr>
</table>
</div>
<div class="footer">
<p><strong>Pipeline Information</strong></p>
<p>Application: {Config.APP_NAME}</p>
<p>Input Topic: {Config.INPUT_TOPIC}</p>
<p>Output Topic: {Config.OUTPUT_TOPIC}</p>
<p style="margin-top:15px">Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
<p style="margin-top:10px;font-size:11px">Automated report from Kafka Streaming Pipeline</p>
</div>
</div>
</body>
</html>"""

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = Config.EMAIL_FROM
        msg['To'] = Config.EMAIL_TO
        msg.attach(MIMEText(body, 'html'))

        logger.info(f"📧 Sending email to {Config.EMAIL_TO}")
        
        with smtplib.SMTP(Config.SMTP_HOST, Config.SMTP_PORT) as server:
            server.starttls()
            if Config.SMTP_USERNAME and Config.SMTP_PASSWORD:
                server.login(Config.SMTP_USERNAME, Config.SMTP_PASSWORD)
            server.send_message(msg)
        
        logger.info("✓ Email sent successfully")
        return True
        
    except Exception as e:
        logger.error(f"✗ Email failed: {e}", exc_info=True)
        return False


# ---------------------------------------------------------------------------
# SCHEDULED SHUTDOWN MANAGER
# ---------------------------------------------------------------------------

class ScheduledShutdownManager:
    """Monitors time and triggers midnight shutdown with email report."""
    
    def __init__(self):
        self.shutdown_triggered = False
        self.monitor_thread = None
        self.running = False

    def start(self):
        self.running = True
        self.monitor_thread = threading.Thread(target=self._monitor_schedule, daemon=True)
        self.monitor_thread.start()
        logger.info(f"🕐 Scheduled shutdown: {Config.SHUTDOWN_HOUR:02d}:{Config.SHUTDOWN_MINUTE:02d} daily")
        if Config.ENABLE_AUTO_RESTART:
            logger.info(f"♻️  Auto-restart: {Config.RESTART_DELAY_MINUTES} min delay")

    def _monitor_schedule(self):
        while self.running:
            now = datetime.now()
            if (now.hour == Config.SHUTDOWN_HOUR and 
                now.minute == Config.SHUTDOWN_MINUTE and
                not self.shutdown_triggered):
                logger.info("⏰ Scheduled shutdown time reached!")
                self.shutdown_triggered = True
                self._execute_shutdown()
                time.sleep(120)
                self.shutdown_triggered = False
            time.sleep(30)

    def _execute_shutdown(self):
        try:
            logger.info("="*80)
            logger.info("🌙 MIDNIGHT SHUTDOWN SEQUENCE INITIATED")
            logger.info("="*80)
            
            logger.info("📊 Collecting daily statistics...")
            daily_summary = stats.get_daily_summary()
            
            logger.info("📧 Sending daily email report...")
            send_email_report(daily_summary)
            
            logger.info("\n" + "=" * 60)
            logger.info(" DAILY SUMMARY - " + daily_summary['date'])
            logger.info("=" * 60)
            logger.info(f"  Runtime:          {daily_summary['runtime_hours']} hours")
            logger.info(f"  Records Processed: {daily_summary['total_read']:,}")
            logger.info(f"  Records Written:   {daily_summary['total_written']:,}")
            logger.info(f"  Batches:           {daily_summary['total_batches']:,}")
            logger.info(f"  Success Rate:      {daily_summary['success_rate']}%")
            logger.info(f"  Throughput:        {daily_summary['avg_throughput_per_hour']:,} rec/hr")
            logger.info("=" * 60 + "\n")
            
            stats.reset_daily_stats()
            time.sleep(5)
            _shutdown_handler(signal.SIGTERM, None, scheduled=True)
            
        except Exception as e:
            logger.error(f"❌ Shutdown error: {e}", exc_info=True)
            _shutdown_handler(signal.SIGTERM, None, scheduled=True)

    def stop(self):
        self.running = False


shutdown_manager = ScheduledShutdownManager()


# ---------------------------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------------------------

def get_password(spark, password_alias, ingestion_credentials):
    password = ''
    if password_alias:
        conf = spark.sparkContext._jsc.hadoopConfiguration()
        conf.set('hadoop.security.credential.provider.path', ingestion_credentials)
        access_key = conf.getPassword(password_alias)
        for i in range(access_key.__len__()):
            password += str(access_key.__getitem__(i))
    return password


def _kafka_security_options(spark) -> Dict[str, str]:
    opts = {}
    if Config.KAFKA_SECURITY_PROTOCOL:
        opts["kafka.security.protocol"] = Config.KAFKA_SECURITY_PROTOCOL
    if Config.KAFKA_SASL_MECHANISM:
        opts["kafka.sasl.mechanism"] = Config.KAFKA_SASL_MECHANISM
    if Config.KAFKA_SASL_USERNAME and Config.KAFKA_SASL_PASSWORD:
        password = get_password(spark, Config.KAFKA_SASL_PASSWORD, Config.INGESTION_CREDENTIALS)
        opts["kafka.sasl.jaas.config"] = (
            f'org.apache.kafka.common.security.scram.ScramLoginModule required '
            f'username="{Config.KAFKA_SASL_USERNAME}" password="{password}";'
        )
    return opts


def build_spark_session() -> SparkSession:
    logger.info("Building SparkSession...")
    spark = (
        SparkSession.builder
        .appName(Config.APP_NAME)
        .config("spark.sql.streaming.kafka.enableIdempotentProducer", "true")
        .config("spark.sql.streaming.maxTriggerDelay", "0s")
        .config("spark.sql.streaming.checkpointInterval", "30s")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    logger.info(f"✓ SparkSession ready — {Config.APP_NAME}")
    return spark


def clean_checkpoint_if_requested():
    if Config.CLEAN_CHECKPOINT_ON_START.lower() == "true":
        import shutil
        for path in (Config.CHECKPOINT_LOCATION, Config.DLQ_CHECKPOINT_LOCATION):
            if os.path.isdir(path):
                shutil.rmtree(path)
                logger.warning(f"Checkpoint removed: {path}")


_active_queries: List[StreamingQuery] = []


def _shutdown_handler(signum: int, frame, scheduled: bool = False):
    logger.info(f"🛑 Shutdown — Signal: {signum}, Scheduled: {scheduled}")
    shutdown_manager.stop()
    
    for q in _active_queries:
        try:
            if q.isActive:
                q.stop()
                logger.info(f"Stopped query: {q.name}")
        except Exception as e:
            logger.error(f"Error stopping {q.name}: {e}")
    
    logger.info("✓ All queries stopped")
    
    if scheduled and Config.ENABLE_AUTO_RESTART:
        logger.info("="*80)
        logger.info(f"♻️  Waiting {Config.RESTART_DELAY_MINUTES} minutes before restart...")
        logger.info("="*80)
        time.sleep(Config.RESTART_DELAY_MINUTES * 60)
        logger.info("🚀 Restarting application...")
        os.execl(sys.executable, sys.executable, *sys.argv)
    else:
        logger.info("👋 Exiting")
        sys.exit(0)


def register_shutdown_hooks():
    signal.signal(signal.SIGTERM, lambda s, f: _shutdown_handler(s, f, scheduled=False))
    signal.signal(signal.SIGINT, lambda s, f: _shutdown_handler(s, f, scheduled=False))
    atexit.register(lambda: logger.info("Process exiting"))


def read_kafka_stream(spark: SparkSession) -> DataFrame:
    logger.info(f"Configuring Kafka — topic={Config.INPUT_TOPIC}, maxOffsets={Config.MAX_OFFSETS_PER_TRIGGER}")
    reader = (
        spark.readStream.format("kafka")
        .option("kafka.bootstrap.servers", Config.KAFKA_BOOTSTRAP_SERVERS)
        .option("kafka.group.id", Config.INPUT_TOPIC_GROUP_ID)
        .option("subscribe", Config.INPUT_TOPIC)
        .option("startingOffsets", Config.STARTING_OFFSETS)
        .option("maxOffsetsPerTrigger", Config.MAX_OFFSETS_PER_TRIGGER)
        .option("failOnDataLoss", "true")
    )
    for k, v in _kafka_security_options(spark).items():
        reader = reader.option(k, v)
    return reader.load()


def _write_batch_to_kafka(spark: SparkSession, batch_df: DataFrame, topic: str) -> int:
    if batch_df.isEmpty():
        return 0
    count = batch_df.count()
    writer = (
        batch_df.write.format("kafka")
        .option("kafka.bootstrap.servers", Config.KAFKA_BOOTSTRAP_SERVERS)
        .option("topic", topic)
        .option("kafka.enable.idempotence", Config.KAFKA_PRODUCER_IDEMPOTENT)
    )
    for k, v in _kafka_security_options(spark).items():
        writer = writer.option(k, v)
    writer.save()
    return count


def parse_and_validate(raw_df: DataFrame) -> DataFrame:
    raw = raw_df.selectExpr("CAST(key AS STRING) AS key", "CAST(value AS STRING) AS value")
    parsed = raw.withColumn("parsed", from_json(col("value"), INPUT_SCHEMA))
    return parsed.select("*").withColumn(
        "is_invalid",
        when(col("key").isNull() | col("parsed.PRIMEKEY").isNull(), lit(True)).otherwise(lit(False))
    )


def prepare_output(filtered_df: DataFrame) -> DataFrame:
    return filtered_df.selectExpr("CAST(key AS STRING) AS key", "CAST(value AS STRING) AS value")


def process_batch(batch_df: DataFrame, batch_id: int):
    spark = batch_df.sparkSession
    t0 = time.time()

    records_read = batch_df.count()
    if records_read == 0:
        return

    validated_df = parse_and_validate(batch_df)
    valid_df = validated_df.filter(col("is_invalid") == False)
    invalid_df = validated_df.filter(col("is_invalid") == True)

    records_valid = valid_df.count()
    records_invalid = invalid_df.count()

    filtered_df = valid_df.filter(col('parsed.ENTITY_APPLICATION') == "ACQUIRER").drop("parsed", "is_invalid")
    records_filtered = filtered_df.count()
    records_dropped = records_valid - records_filtered

    output_df = prepare_output(filtered_df)
    records_written = _write_batch_to_kafka(spark, output_df, Config.OUTPUT_TOPIC)
    records_dlq_written = 0

    latency_ms = (time.time() - t0) * 1000
    stats.add(records_read, records_valid, records_invalid, records_filtered, 
              records_dropped, records_written, records_dlq_written, latency_ms)


def main():
    register_shutdown_hooks()
    clean_checkpoint_if_requested()
    spark = build_spark_session()
    shutdown_manager.start()

    raw_df = read_kafka_stream(spark)
    logger.info("✓ Kafka source configured")

    query = (
        raw_df.writeStream
        .foreachBatch(process_batch)
        .queryName("MainPipelineQuery")
        .option("checkpointLocation", Config.CHECKPOINT_LOCATION)
        .trigger(processingTime=f"{Config.TRIGGER_INTERVAL_SECS} seconds")
        .start()
    )
    _active_queries.append(query)
    
    logger.info("="*80)
    logger.info(f"🚀 Pipeline started — shutdown at {Config.SHUTDOWN_HOUR:02d}:{Config.SHUTDOWN_MINUTE:02d}")
    logger.info("="*80)

    try:
        while True:
            if not query.isActive:
                logger.error(f"Query died! Exception: {query.exception()}")
                _shutdown_handler(0, None)
            time.sleep(10)
    except Exception as e:
        logger.exception(f"Monitoring error: {e}")
        _shutdown_handler(0, None)


if __name__ == "__main__":
    main()
